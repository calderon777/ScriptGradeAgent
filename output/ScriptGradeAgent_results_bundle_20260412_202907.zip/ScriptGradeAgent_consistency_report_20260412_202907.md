# Consistency Report

Scripts processed: 5
Configured maximum mark: 85

## Qwen2_7B

Successful scripts: 4
Failed scripts: 1
Detected parts median: 4
Extracted words median: 3834
Possible extraction issues: 3
Calibrated marks changed: 0
AI/math median delta: 22.07
AI/math max delta: 25.15
AI/math disagreements over 3 marks: 2
Marks returned: 4
Mean mark: 75.04
Median mark: 74.00
Min / Max: 67.15 / 85.00
Distinct marks: 67.15, 68, 80, 85
Top-mark rate: 1/4 (25.0%)

### Mark Distribution

- 67.15: 1
- 68: 1
- 80: 1
- 85: 1

### Repeated Feedback Starts

- 1x: The student has demonstrated a comprehensive understanding of the theoretical models and
- 1x: The response demonstrates a comprehensive understanding of the theoretical framework and its
- 1x: The student demonstrated a strong grasp of economic theory and its application
- 1x: The response demonstrates a comprehensive understanding of the policy and its implications

### Error Summary

- 1x: Model did not explicitly cover all detected sections: Section above

### Validation Notes

- 3x: possible_extraction_issue
- 2x: math_total_used
- 2x: part_score_spread=75.00
- 2x: math_total_unavailable
- 1x: part_score_spread=21.00

### AI vs Math Total Differences

- EC3040 Individual Coursework.docx: AI 42, Math 67.15
- EC3040 Economics and Society individual coursework.docx: AI 49, Math 68
