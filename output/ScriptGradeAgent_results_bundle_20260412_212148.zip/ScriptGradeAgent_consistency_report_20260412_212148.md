# Consistency Report

Scripts processed: 5
Configured maximum mark: 85

## Qwen2_7B

Successful scripts: 2
Failed scripts: 3
Detected parts median: 4
Extracted words median: 3340
Possible extraction issues: 2
Calibrated marks changed: 0
Marks returned: 2
Mean mark: 71.83
Median mark: 71.83
Min / Max: 71.40 / 72.25
Distinct marks: 71.40, 72.25
Top-mark rate: 0/2 (0.0%)

### Mark Distribution

- 71.40: 1
- 72.25: 1

### Repeated Feedback Starts

- 1x: The submission demonstrates a comprehensive understanding of the theoretical framework and empirical
- 1x: The submission demonstrates a comprehensive understanding of economic models and their application

### Error Summary

- 1x: Model did not explicitly cover all detected sections: Part 4
- 1x: Could not compute deterministic total from part scores.
- 1x: Model did not explicitly cover all detected sections: Section above

### Validation Notes

- 2x: possible_extraction_issue
- 2x: math_total_used
- 1x: part_score_spread=27.00
- 1x: part_score_spread=26.00
